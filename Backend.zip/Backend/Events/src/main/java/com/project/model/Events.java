package com.project.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Events {
	
	@Id
	@GeneratedValue
	private int eventid;
	private String eventname;
	private String place;
	private float budget;
	private String date;
	private String time;
	private String description;
	private int rid;
	private long rnumber;
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEventname() {
		return eventname;
	}
	public void setEventname(String eventname) {
		this.eventname = eventname;
	}
	public long getRnumber() {
		return rnumber;
	}
	public void setRnumber(long rnumber) {
		this.rnumber = rnumber;
	}
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}

	public float getBudget() {
		return budget;
	}
	public void setBudget(float budget) {
		this.budget = budget;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Events() {
		// TODO Auto-generated constructor stub
	}
	
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public Events(String eventname, String place, float budget, String date, String time, String description, int rid,
			long rnumber) {
		super();
		this.eventname = eventname;
		this.place = place;
		this.budget = budget;
		this.date = date;
		this.time = time;
		this.description = description;
		this.rid = rid;
		this.rnumber = rnumber;
	}
	public Events( String eventname, String place, float budget, String date, String time,
			String description, int rid,String status) {
		super();
		
		this.eventname = eventname;
		this.place = place;
		this.budget = budget;
		this.date = date;
		this.time = time;
		this.description = description;
		this.rid = rid;
		this.status=status;
		
	}
	
}
