package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Member {
	
	@Id
	@GeneratedValue
	private int id;
	private String mtype;
	private String fname;
	private String mname;
	private String lname;
	private int wingno;
	private int flatno;
	private int count;
	private long number;
	private String password;
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMtype() {
		return mtype;
	}

	public void setMtype(String mtype) {
		this.mtype = mtype;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public int getWingno() {
		return wingno;
	}

	public void setWingno(int wingno) {
		this.wingno = wingno;
	}

	public int getFlatno() {
		return flatno;
	}

	public void setFlatno(int flatno) {
		this.flatno = flatno;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}
	public Member(String mtype, String fname, String mname, String lname, int wingno, int flatno, int count,
			long number,String password) {
		super();
		this.mtype = mtype;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.wingno = wingno;
		this.flatno = flatno;
		this.count = count;
		this.number = number;
		this.password=password;
	}

	public Member() {
		
	}

}
