package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.*;

public interface amountrepository extends JpaRepository<Amount,Integer> {

}
