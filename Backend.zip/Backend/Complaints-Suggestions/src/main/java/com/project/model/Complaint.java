package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Complaint {
	
	@Id
	@GeneratedValue
	private int id;
	private String date;
	private String description;
	private int complaintant_id;
	private int rid;
	private int respondent_id;
	private String status;
	private String solution;
	public int getComplaintant_id() {
		return complaintant_id;
	}
	public void setComplaintant_id(int complaintant_id) {
		this.complaintant_id = complaintant_id;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public int getRespondent_id() {
		return respondent_id;
	}
	public void setRespondent_id(int respondent_id) {
		this.respondent_id = respondent_id;
	}
	public Complaint() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
	}
	public Complaint(String date, String description, int complaintant_id, int rid, int respondent_id, String status,
			String solution) {
		super();
		this.date = date;
		this.description = description;
		this.complaintant_id = complaintant_id;
		this.rid = rid;
		this.respondent_id = respondent_id;
		this.status = status;
		this.solution = solution;
	}
	public Complaint(String date, String description, int complaintant_id, int rid, String status) {
		super();
		this.date = date;
		this.description = description;
		this.complaintant_id = complaintant_id;
		this.rid = rid;
		this.status = status;
	}
	public Complaint(String date, String description, int complaintant_id, String status) {
		super();
		this.date = date;
		this.description = description;
		this.complaintant_id = complaintant_id;
		
		this.status = status;
	}
	public Complaint(String date, String description, int complaintant_id, int rid, String status, String solution) {
		super();
		this.date = date;
		this.description = description;
		this.complaintant_id = complaintant_id;
		this.rid = rid;
		this.status = status;
		this.solution = solution;
	}
	public Complaint(String date, String description, int complaintant_id,  String status, String solution) {
		super();
		this.date = date;
		this.description = description;
		this.complaintant_id = complaintant_id;
		this.rid = rid;
		this.status = status;
		this.solution = solution;
	}
	
	
	
	
	
	
	

}
