package com.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.project.model.Complaint;
import com.project.model.Suggestion;
import com.project.repository.complaintrepository;
import com.project.repository.suggestionrepository;

@SpringBootApplication
@EnableDiscoveryClient
public class Application implements CommandLineRunner {
	
	@Autowired
	complaintrepository crespo;
	
	@Autowired
	suggestionrepository srespo;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override

	public void run(String... args) throws Exception {
//		
//		Complaint c= new Complaint("1-4-2023","Parking car at my parking place",3,2,"pending");
//		Suggestion s = new Suggestion("1-4-2023","Planting plants at the entrance and also at the roadside",1,
//				"Pending","Pending at commitie approval for voting");
//		crespo.save(c);	
//		srespo.save(s);
	}

}
