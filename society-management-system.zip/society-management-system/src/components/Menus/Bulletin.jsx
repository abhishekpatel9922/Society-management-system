import React from "react";
import { Container, Card, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";

export default function Bulletin() {
  const options = [
    "Results of Voting",
    "Details of Events",
    "Details of Complaints",
    "Details of Suggestions",
  ];
  return (
    <div>
      <Container
        style={{
          backgroundColor: "white",
          padding: "20px",
          margin: "50px auto",
        }}
      >
        <h2>Bulletin</h2>

        {options.map((option) => {
          let url = option.replace(/ /g, "-").toLowerCase();
          return (
            <Card
              style={{
                maxWidth: "400px",
                margin: "20px auto",
                textDecoration: "none",
                color: "black",
              }}
              as={Link}
              to={url}
            >
              <Card.Header style={{ fontSize: "24px" }}>{option}</Card.Header>
            </Card>
          );
        })}

        <Card
          className="no-highlight"
          style={{ maxWidth: "300px", margin: "auto", fontSize: "20px" }}
          as={Link}
          to="/communitywiki"
        >
          Community WIKI
        </Card>
      </Container>
    </div>
  );
}
