import React, { useEffect, useRef, useState } from "react";
import { useRecoilState } from "recoil";
import { userIdState } from "../../atoms";
import axios from "axios";
import { Button, Container, Form, Modal, Table } from "react-bootstrap";
import { formattedDate } from "../../utils/Date";

export default function Accounting() {
  const [userId, setUserId] = useRecoilState(userIdState);
  const [type, setType] = useState("Unpaid");
  const [bills, setBills] = useState();
  useEffect(() => {
    const getUnpaidBills = async () => {
      const res = await axios.get(
        `http://localhost:5000/getbills/${userId}?status=${type}`
      );
      setBills(res.data);
    };
    getUnpaidBills();
  }, [type]);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [billNo, setbillNo] = useState();
  const pay = async (id) => {
    handleShow();
    setbillNo(id);
  };

  const cityRef = useRef();
  const streetRef = useRef();
  const zipCodeRef = useRef();
  const countryRef = useRef();

  const completed = async () => {
    let street = streetRef.current.value;
    let city = cityRef.current.value;
    let country = countryRef.current.value;
    let zipCode = zipCodeRef.current.value;
    if ((street, city, country, zipCode)) {
      const res = await axios.put(`http://localhost:5000/payment/${billNo}`, {
        date: formattedDate(),
        street: street,
        city: city,
        country: country,
        zipcode: zipCode,
      });
      if (res.data.status == "Paid") {
        alert("Bill paid");
      } else {
        alert("Something went wrong");
      }
    } else {
      alert("Fill details");
    }
  };

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <h2>Accounting</h2>
      <br />
      <Button onClick={() => setType("Unpaid")}>Dues</Button>{" "}
      <Button onClick={() => setType("Paid")}>History</Button>
      <br />
      <br />
      <h3>{type == "Unpaid" ? "Dues" : "History"}</h3>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Fill Online Payment Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Label>Enter City*</Form.Label>
          <Form.Control
            type="text"
            ref={cityRef}
            placeholder="Enter City Name"
            required
          />
          <Form.Label>Enter Street name*</Form.Label>
          <Form.Control
            type="text"
            ref={streetRef}
            placeholder="Enter Street Name"
            required
          />
          <Form.Label>Enter ZipCode name*</Form.Label>
          <Form.Control
            type="text"
            ref={zipCodeRef}
            placeholder="Enter ZipCode Name"
            required
          />
          <Form.Label>Enter Country name*</Form.Label>
          <Form.Control
            type="text"
            ref={countryRef}
            placeholder="Enter Country Name"
            required
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="success" onClick={completed}>
            Pay
          </Button>
        </Modal.Footer>
      </Modal>
      <br />
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th rowSpan={"2"}>Bill Id</th>
            <th rowSpan={"2"}>Due Month</th>
            <th colSpan={"5"}>Amount</th>
            <th rowSpan={"2"}>Total</th>
            <th rowSpan={"2"}>Status</th>
            {type == "Unpaid" && <th rowSpan={"2"}>Pay</th>}
          </tr>
          <tr>
            <th>All muncipal Dues</th>
            <th>Administrative and General Expenses</th>
            <th> Periodic Building's Maintainance Expenses</th>
            <th>Common Area Utilization</th>
            <th>Non Occupancuy Charges</th>
          </tr>
        </thead>
        <tbody>
          {bills?.map((e) => {
            let mdues = e.amount.mdues ?? 0;
            let general = e.amount.general ?? 0;
            let building = e.amount.building ?? 0;
            let common = e.amount.common ?? 0;
            let charges = e.amount.charges ?? 0;
            let total = mdues + general + building + common + charges;
            console.log(total);
            return (
              <tr>
                <td>{e.billNo}</td>
                <td>{e.billmotnth}</td>
                <td>{mdues}</td>
                <td>{general}</td>
                <td>{building}</td>
                <td>{common}</td>
                <td>{charges}</td>
                <td>{total}</td>
                <td>{e.status}</td>
                {type == "Unpaid" && (
                  <td>
                    <Button variant="success" onClick={() => pay(e.billNo)}>
                      Pay
                    </Button>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </Table>
    </Container>
  );
}
