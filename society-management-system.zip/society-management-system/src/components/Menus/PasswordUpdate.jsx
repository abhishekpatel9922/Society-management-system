import React, { useEffect, useRef, useState } from "react";
import {
  Container,
  Form,
  Row,
  Button,
  Col,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import { useRecoilState } from "recoil";
import { userIdState, userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import { createMember, updateMember } from "../../utils/auth";
import axios from "axios";
import { passwordValidate } from "../../utils/validate";

export default function PasswordUpdate() {
  const [userType, setUserType] = useRecoilState(userTypeState);
  const [userId, setUserId] = useRecoilState(userIdState);
  const [person, setPerson] = useState();

  useEffect(() => {
    const getPerson = async () => {
      const res = await axios.get(`http://localhost:1000/member/${userId}`);
      console.log(res.data);
      setPerson(res.data);
    };
    getPerson();
  }, []);

  const fnameRef = person?.fname;
  const mnameRef = person?.mname;
  const lnameRef = person?.lname;
  const wingnoRef = person?.wingno;
  const flatnoRef = person?.flatno;
  const passwordRef = useRef();
  const countRef = person?.count;
  const [mType, setMType] = useState(userType);

  const submit = async (e) => {
    e.preventDefault();
    const isValid = passwordValidate(passwordRef.current.value);
    if (isValid.valid) {
      let data = {
        fname: fnameRef,
        mname: mnameRef,
        lname: lnameRef,
        wingno: wingnoRef,
        flatno: flatnoRef,
        count: countRef,
        password: passwordRef.current.value,
        mtype: mType,
      };
      const res = await updateMember(userId, data);
      if (res.id) {
        alert("Member updated succesfully");
        window.location.reload();
      } else {
        alert("Something went wrong");
        window.location.reload();
      }
    } else {
      alert("Password is not valid");
    }
  };

  

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <br />
      <h2>Update member details</h2>
      <br />
      {person && (
        <Form
          style={{
            border: "1px solid black",
            padding: "10px",
            borderRadius: "10px",
            maxWidth: "500px",
            margin: "auto",
          }}
        >
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicWnumber">
                <Form.Label>Enter New Password*</Form.Label>
                <Form.Control
                  type="text"
                  ref={passwordRef}
                  defaultValue={person.password}
                  placeholder="Enter New Number"
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
            Submit
          </Button>
        </Form>
      )}
    </Container>
  );
}
