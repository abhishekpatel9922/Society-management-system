import React, { useEffect, useState } from "react";
import { Button, Container, Form, Modal, Table } from "react-bootstrap";
import {
  addVote,
  getParticpants,
  isVotedOrNot,
  votingEvents,
} from "../../utils/election";
import { members as allMembers } from "../../utils/complaints";
import { useRecoilState } from "recoil";
import { userIdState } from "../../atoms";
import { checkTime, isDateToday } from "../../utils/Date";

export default function Voting() {
  const [userId, setUserId] = useRecoilState(userIdState);

  const [elections, setElections] = useState();
  const [members, setMembers] = useState();
  useEffect(() => {
    const getAllElections = async () => {
      const res = await votingEvents();
      setElections(res);
    };
    getAllElections();
  }, []);
  console.log(elections);

  const [eid, setEid] = useState();
  const [voteTo, setVoteTo] = useState();
  const [participants, setParticpants] = useState();

  useEffect(() => {
    const getElectionParticpants = async () => {
      if (eid) {
        console.log(eid);
        const res = await getParticpants(eid);
        setParticpants(res.participants);
        console.log(res.participants);
      }
    };
    getElectionParticpants();
    const getMembers = async () => {
      const res = await allMembers();
      setMembers(res);
    };
    getMembers();
  }, [eid]);

  const getName = (id) => {
    return members.filter((member) => member.id == id)[0];
  };

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const vote = async (evid) => {
    const isVoted = await isVotedOrNot(evid, userId);
    if (isVoted == "Yes") {
      alert("Already voted");
    } else {
      handleShow();
      setEid(evid);
    }
  };
  const completed = async () => {
    const res = await addVote(userId, eid, voteTo);
    if (res.success == "true") {
      alert("Thank you for voting");
      window.location.reload();
    }
  };

  return (
    <div>
      <Container
        style={{
          backgroundColor: "white",
          padding: "20px",
          margin: "50px auto",
        }}
      >
        <h2>Voting</h2>
        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Vote</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {participants?.map((p) => {
              let name = getName(p);
              return (
                <Form.Check
                  style={{ maxWidth: "200px", margin: "auto" }}
                  type="radio"
                  name="participants"
                  id={p}
                  onClick={() => setVoteTo(p)}
                  label={`${name.fname} ${name.lname}`}
                />
              );
            })}
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="success" onClick={completed}>
              Vote
            </Button>
          </Modal.Footer>
        </Modal>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>El Id</th>
              <th>E Name</th>
              <th>Date</th>
              <th>From</th>
              <th>To</th>
              <th>Status</th>
              <th>Vote</th>
            </tr>
          </thead>
          <tbody>
            {elections?.map((e) => {
              let status;
              const isToday = isDateToday(e.date);
              if (isToday == "Today") {
                status = checkTime(e.stime, e.etime);
              } else {
                status = isToday;
              }
              if (status == "Ongoing")
                return (
                  <tr>
                    <td>{e.evid}</td>
                    <td>{e.evname}</td>
                    <td>{e.date}</td>
                    <td>{e.stime}</td>
                    <td>{e.etime}</td>
                    <td>{status}</td>
                    <td>
                      <Button onClick={() => vote(e.evid)}>Vote</Button>
                    </td>
                  </tr>
                );
            })}
          </tbody>
        </Table>

        <Table striped bordered hover>
          <thead>
            <tr>
              <th>El Id</th>
              <th>E Name</th>
              <th>Date</th>
              <th>From</th>
              <th>To</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {elections?.map((e) => {
              let status;
              const isToday = isDateToday(e.date);
              if (isToday == "Today") {
                status = checkTime(e.stime, e.etime);
              } else {
                status = isToday;
              }
              return (
                <tr>
                  <td>{e.evid}</td>
                  <td>{e.evname}</td>
                  <td>{e.date}</td>
                  <td>{e.stime}</td>
                  <td>{e.etime}</td>
                  <td>{status}</td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Container>
    </div>
  );
}
