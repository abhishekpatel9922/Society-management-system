import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import {
  Form,
  Button,
  Container,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import { formattedDate } from "../../utils/Date";
import { useRecoilState } from "recoil";
import { userIdState } from "../../atoms";
import {
  createComplaint,
  createComplaintWithoutName,
} from "../../utils/complaints";

function Complient() {
  const [members, setMembers] = useState();
  const [userId, setUserId] = useRecoilState(userIdState);

  const cmpDescriptionRef = useRef();
  const cmpSolutionRef = useRef();
  const [cmpRespondentName, setCmpRespondentName] = useState([null, null]);

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);
  console.log(members);
  const cmpSubmit = async (e) => {
    e.preventDefault();
    let date = formattedDate();
    let description = cmpDescriptionRef.current.value;
    let mid = userId;
    let fname = cmpRespondentName[0];
    let lname = cmpRespondentName[1];
    let solution = cmpSolutionRef.current.value;
    console.log(fname, lname);
    if (fname == null && lname == null) {
      const response = await createComplaintWithoutName(
        date,
        description,
        mid,
        solution
      );
      if (response) {
        alert("Success, Complaint Filed");
      } else {
        alert("Failed, Something Went Wrong");
      }
      window.location.reload();
    } else {
      const response = await createComplaint(
        date,
        description,
        fname,
        lname,
        mid,
        solution
      );
      if (response) {
        alert("Success, Complaint Filed");
      } else {
        alert("Failed, Something Went Wrong");
      }
      window.location.reload();
    }
  };

  return (
    <div>
      <Form
        style={{
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <h3>Complient</h3>
        <hr />
        <Form.Group className="mb-3" controlId="formBasicDescription">
          <Form.Label>Complient Description*</Form.Label>
          <Form.Control
            as="textarea"
            rows={5}
            placeholder="Complient Description"
            ref={cmpDescriptionRef}
            required
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicSolution">
          <Form.Label>Solution</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            placeholder="Solution..."
            ref={cmpSolutionRef}
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicRespondent">
          <Form.Label>Respondent Name*</Form.Label>
          <DropdownButton
            id="dropdown-basic-button"
            title={cmpRespondentName ? cmpRespondentName[0] : "Choose Name"}
          >
            {members?.map((member) => {
              return (
                <Dropdown.Item
                  onClick={() =>
                    setCmpRespondentName([member.fname, member.lname])
                  }
                >
                  {member.fname}
                </Dropdown.Item>
              );
            })}
          </DropdownButton>
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => cmpSubmit(e)}>
          Submit
        </Button>
      </Form>
    </div>
  );
}

function Suggestion() {
  const [userId, setUserId] = useRecoilState(userIdState);
  const descriptionRef = useRef();
  const submit = async (e) => {
    e.preventDefault();
    if (
      descriptionRef.current.value !== null &&
      descriptionRef.current.value !== ""
    ) {
      const res = await axios.post(`http://localhost:4000/suggestion`, null, {
        params: {
          date: formattedDate(),
          description: descriptionRef.current.value,
          rid: userId,
        },
      });
      if (res.data.id) {
        alert("Suggestion added succesfully");
        window.location.reload();
      } else {
        alert("Failed! Something went wrong");
        window.location.reload();
      }
    }
  };
  return (
    <div>
      <Form
        style={{
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <h3>Suggestion</h3>
        <hr />
        <Form.Group className="mb-3" controlId="form2BasicDescription">
          <Form.Label>Suggestrion Description*</Form.Label>
          <Form.Control
            as="textarea"
            ref={descriptionRef}
            placeholder="Suggestion/Idea ....."
            rows={5}
            required
          />
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
          Submit
        </Button>
      </Form>
    </div>
  );
}

export default function ComplientSuggestion() {
  const [formType, setFormType] = useState("complient");
  return (
    <div>
      <Container
        style={{
          backgroundColor: "white",
          padding: "20px",
          margin: "50px auto",
          maxWidth: "500px",
        }}
      >
        <h2>Complient and Suggestion</h2>
        <hr />
        <Button onClick={() => setFormType("complient")} className="mb-3">
          Complient
        </Button>{" "}
        <Button onClick={() => setFormType("suggestion")} className="mb-3">
          Suggestion
        </Button>
        {formType == "complient" && <Complient />}
        {formType == "suggestion" && <Suggestion />}
      </Container>
    </div>
  );
}
