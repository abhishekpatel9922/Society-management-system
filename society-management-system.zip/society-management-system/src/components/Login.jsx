import React, { useRef } from "react";
import { Button, Card, Container } from "react-bootstrap";
import { useRecoilState } from "recoil";
import {
  isUserLoggedInState,
  userIdState,
  userNameState,
  userNumberState,
  userTypeState,
} from "../atoms";
import { validateData } from "../utils/validate";
import { auth } from "../utils/auth";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [isUserLoggedIn, setIsUserLoggedIn] =
    useRecoilState(isUserLoggedInState);
  const [userId, setUserId] = useRecoilState(userIdState);
  const [userNumber, setUserNumber] = useRecoilState(userNumberState);
  const [userName, setUserName] = useRecoilState(userNameState);
  const [userType, setUserType] = useRecoilState(userTypeState);

  const numberRef = useRef();
  const passwordref = useRef();

  const navigate = useNavigate();

  const signin = async () => {
    const isValid = validateData(
      numberRef.current.value,
      passwordref.current.value
    );
    if (!isValid.valid) {
      console.log(isValid.error);
    }
    const res = await auth(numberRef.current.value, passwordref.current.value);
    console.log(res);
    if (res.success === "true") {
      setIsUserLoggedIn(true);
      setUserType(res.type);
      setUserId(res.id);
      setUserName(res.name);
      setUserNumber(numberRef.current.value);
      window.localStorage.setItem(
        `userToken`,
        btoa(
          `${numberRef.current.value} ${passwordref.current.value} ${res.id} ${res.name} ${res.type}`
        )
      );
      alert("Login Success");
    } else {
      alert("Invalid Details");
    }
    //reset
    numberRef.current.value = "";
    passwordref.current.value = "";
  };

  return (
    <div className="login-bg" style={{ padding: "100px" }}>
      <Card
        style={{
          maxWidth: "400px",
          margin: "auto",
        }}
      >
        <Card.Body>
          <Card.Title>Login</Card.Title>
          <hr />
          <h4>Enter number</h4>
          <input
            placeholder="Enter number"
            type="number"
            ref={numberRef}
            required
          />
          <h5>Password</h5>
          <input
            placeholder="Enter Password"
            type="password"
            ref={passwordref}
            required
          />
          <br />
          <br />
          <Button variant="primary" onClick={signin}>
            Sign In
          </Button>
        </Card.Body>
      </Card>
    </div>
  );
}
