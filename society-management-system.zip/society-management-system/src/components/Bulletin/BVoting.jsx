import React, { useEffect, useState } from "react";
import { getResults, results, votingEvents } from "../../utils/election";
import { Button, Container, Modal, Table } from "react-bootstrap";
import { checkTime, isDateToday } from "../../utils/Date";
import axios from "axios";

export default function BVoting() {
  const [elections, setElections] = useState();
  const [members, setMembers] = useState();

  useEffect(() => {
    const getAllElections = async () => {
      const res = await votingEvents();
      setElections(res);
    };
    getAllElections();
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  const [electionResult, setElectionResult] = useState();
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const getName = (id) => {
    const name = members?.filter((member) => member.id === id);
    if (name) {
      return name[0];
    }
  };

  const result = async (id) => {
    const res = await getResults(id);
    const result = results(res);
    setElectionResult(result);
    handleShow();
  };

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Election Results</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {electionResult?.length > 2 && <h5>Tie among</h5>}
          {electionResult?.length == 2 && <h5>Tie between</h5>}
          {electionResult?.length == 1 && <h5>Winner</h5>}
          {electionResult?.map((res) => {
            let name = getName(res);
            return (
              <li style={{ fontSize: "20px" }}>
                {name?.fname} {name?.lname}
              </li>
            );
          })}
        </Modal.Body>
      </Modal>
      <br />
      <h2>Completed Election results</h2>
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>El Id</th>
            <th>E Name</th>
            <th>Date</th>
            <th>From</th>
            <th>To</th>
            <th>Results</th>
          </tr>
        </thead>
        <tbody>
          {elections?.map((e) => {
            let status;
            const isToday = isDateToday(e.date);
            if (isToday == "Today") {
              status = checkTime(e.stime, e.etime);
            } else {
              status = isToday;
            }
            if (status == "Expired")
              return (
                <tr>
                  <td>{e.evid}</td>
                  <td>{e.evname}</td>
                  <td>{e.date}</td>
                  <td>{e.stime}</td>
                  <td>{e.etime}</td>
                  <td>
                    <Button onClick={() => result(e.evid)}>Results</Button>
                  </td>
                </tr>
              );
          })}
        </tbody>
      </Table>
      <br />
      <h2>All Elections</h2>
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>El Id</th>
            <th>E Name</th>
            <th>Date</th>
            <th>From</th>
            <th>To</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {elections?.map((e) => {
            let status;
            const isToday = isDateToday(e.date);
            if (isToday == "Today") {
              status = checkTime(e.stime, e.etime);
            } else {
              status = isToday;
            }
            return (
              <tr>
                <td>{e.evid}</td>
                <td>{e.evname}</td>
                <td>{e.date}</td>
                <td>{e.stime}</td>
                <td>{e.etime}</td>
                <td>{status}</td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </Container>
  );
}
