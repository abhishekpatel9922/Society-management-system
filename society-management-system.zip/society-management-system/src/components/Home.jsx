import React from "react";
import { Container, Card, Row, Col } from "react-bootstrap";
import {
  Balloon,
  BalloonFill,
  CardList,
  HandIndexThumb,
  HandIndexThumbFill,
  Mailbox,
  Mailbox2,
  PersonAdd,
  PersonLock,
  PersonUp,
  Receipt,
  ReceiptCutoff,
} from "react-bootstrap-icons";
import { Link } from "react-router-dom";
import { useRecoilState } from "recoil";
import { userTypeState } from "../atoms";

export default function Home() {
  const [userType, setUserType] = useRecoilState(userTypeState);

  return (
    <div>
      <Container
        style={{
          backgroundColor: "white",
          padding: "20px",
          margin: "50px auto",
        }}
      >
        <Row>
          <h3>General Menu</h3>
          <Col>
            <Card
              style={{ margin: "30px", cursor: "pointer" }}
              className="no-highlight"
              as={Link}
              to={"/bulletin"}
            >
              <CardList className="home-icon" />
              <Card.Header>Bulletin</Card.Header>
            </Card>
          </Col>
          <Col>
            <Card
              style={{ margin: "30px", cursor: "pointer" }}
              className="no-highlight"
              as={Link}
              to={"/voting"}
            >
              <HandIndexThumb className="home-icon" />
              <Card.Header>Voting</Card.Header>
            </Card>
          </Col>
          <Col>
            <Card
              style={{ margin: "30px", cursor: "pointer" }}
              className="no-highlight"
              as={Link}
              to={"/complaint-suggestion"}
            >
              <Mailbox className="home-icon" />
              <Card.Header>Complaint/Suggestion</Card.Header>
            </Card>
          </Col>
          <Col>
            <Card
              style={{ margin: "30px", cursor: "pointer" }}
              className="no-highlight"
              as={Link}
              to={"/accounting"}
            >
              <Receipt className="home-icon" />
              <Card.Header>Accounting</Card.Header>
            </Card>
          </Col>
          <Col>
            <Card
              style={{ margin: "30px", cursor: "pointer" }}
              className="no-highlight"
              as={Link}
              to={"/events-scheduling"}
            >
              <Balloon className="home-icon" />
              <Card.Header>Events Scheduling</Card.Header>
            </Card>
          </Col>
          <Col>
            <Card
              style={{ margin: "30px", cursor: "pointer" }}
              className="no-highlight"
              as={Link}
              to={"/password-update"}
            >
              <PersonLock className="home-icon" />
              <Card.Header>Password Update</Card.Header>
            </Card>
          </Col>
        </Row>
        {userType == "commitie" && (
          <>
            <hr />
            <h3>Commitite Menu</h3>
            <Row style={{ marginTop: "50px" }}>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/voting-contoller"}
                >
                  <HandIndexThumbFill className="home-icon" />
                  <Card.Header>Voting Contoller</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/accounting-contoller"}
                >
                  <ReceiptCutoff className="home-icon" />
                  <Card.Header>Accounting Contoller</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/events-contoller"}
                >
                  <BalloonFill className="home-icon" />
                  <Card.Header>Events Contoller</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/complaint-suggestion-contoller"}
                >
                  <Mailbox2 className="home-icon" />
                  <Card.Header>Complaint/Suggestion Contoller</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/register-member"}
                >
                  <PersonAdd className="home-icon" />
                  <Card.Header>Create New Member</Card.Header>
                </Card>
              </Col>
              <Col>
                <Card
                  style={{ margin: "30px", cursor: "pointer" }}
                  className="no-highlight"
                  as={Link}
                  to={"/update-member"}
                >
                  <PersonUp className="home-icon" />
                  <Card.Header>Update Member</Card.Header>
                </Card>
              </Col>
            </Row>
          </>
        )}
      </Container>
    </div>
  );
}
