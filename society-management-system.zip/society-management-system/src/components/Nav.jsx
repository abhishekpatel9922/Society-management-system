import React from "react";
import { Navbar } from "react-bootstrap";

export default function Nav() {
  return (
    <div>
      <Navbar
        style={{
          position: "sticky",
          top: "0",
          zIndex: "2",
          color: "white",
          justifyContent: "space-between",
          padding: "10px",
        }}
        expand="lg"
        bg="dark"
        variant="dark"
      >
        <Navbar.Brand href="/">Society Management System</Navbar.Brand>
      </Navbar>
    </div>
  );
}
