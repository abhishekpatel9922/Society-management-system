import React, { useEffect, useRef, useState } from "react";
import {
  Container,
  Form,
  Row,
  Button,
  Col,
  DropdownButton,
  Dropdown,
} from "react-bootstrap";
import { useRecoilState } from "recoil";
import { userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import { createMember, updateMember } from "../../utils/auth";
import axios from "axios";

export default function CUpdateMember() {
  const [userType, setUserType] = useRecoilState(userTypeState);

  const fnameRef = useRef();
  const mnameRef = useRef();
  const lnameRef = useRef();
  const wingnoRef = useRef();
  const flatnoRef = useRef();
  const passwordRef = useRef();
  const countRef = useRef();
  const [mType, setMType] = useState("Society");

  const [members, setMembers] = useState();
  const [personName, setPersonName] = useState();
  const [person, setPerson] = useState();

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    let data = {
      fname: fnameRef.current.value,
      mname: mnameRef.current.value,
      lname: lnameRef.current.value,
      wingno: wingnoRef.current.value,
      flatno: flatnoRef.current.value,
      count: countRef.current.value,
      password: person?.password,
      mtype: person?.mType,
      
    };
    const res = await updateMember(personName[2], data);
    if (res.id) {
      alert("Member updated succesfully");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  if (userType !== "commitie") {
    return <PageNotFound />;
  }

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <br />
      <h2>Update member details</h2>
      <br />
      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label>Person Name*</Form.Label>
        <DropdownButton
          id="dropdown-basic-button"
          title={
            personName ? `${personName[0]} ${personName[1]}` : "Choose Name"
          }
        >
          {members?.map((member) => {
            return (
              <Dropdown.Item
                onClick={() => {
                  setPersonName([member.fname, member.lname, member.id]);
                  setPerson(member);
                }}
              >
                {`${member.fname} ${member.lname}`}
              </Dropdown.Item>
            );
          })}
        </DropdownButton>
      </Form.Group>
      {person && (
        <Form
          style={{
            border: "1px solid black",
            padding: "10px",
            borderRadius: "10px",
            maxWidth: "500px",
            margin: "auto",
          }}
        >
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicFName">
                <Form.Label>Enter First name*</Form.Label>
                <Form.Control
                  type="text"
                  ref={fnameRef}
                  defaultValue={person.fname}
                  placeholder="Enter First Name"
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicMName">
                <Form.Label>Enter Middle name*</Form.Label>
                <Form.Control
                  type="text"
                  ref={mnameRef}
                  defaultValue={person.mname}
                  placeholder="Enter Middle Name"
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicLName">
                <Form.Label>Enter Last name*</Form.Label>
                <Form.Control
                  type="text"
                  ref={lnameRef}
                  defaultValue={person.lname}
                  placeholder="Enter Last Name"
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicEName">
                <Form.Label>Family members count*</Form.Label>
                <Form.Control
                  type="number"
                  defaultValue={person.count}
                  ref={countRef}
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicWnumber">
                <Form.Label>Enter Wing number*</Form.Label>
                <Form.Control
                  type="number"
                  ref={wingnoRef}
                  defaultValue={person.wingno}
                  placeholder="Enter Wing Number"
                  required
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group className="mb-3" controlId="formBasicFnumber">
                <Form.Label>Enter Flat number*</Form.Label>
                <Form.Control
                  type="number"
                  ref={flatnoRef}
                  defaultValue={person.flatno}
                  placeholder="Enter Flat Number"
                  required
                />
              </Form.Group>
            </Col>
          </Row>
          <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
            Submit
          </Button>
        </Form>
      )}
    </Container>
  );
}
