import React, { useRef, useState } from "react";
import { Container, Form, Row, Button, Col } from "react-bootstrap";
import { useRecoilState } from "recoil";
import { userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import { createMember } from "../../utils/auth";
import { passwordValidate } from "../../utils/validate";

export default function CRegisterMember() {
  const [userType, setUserType] = useRecoilState(userTypeState);

  const fnameRef = useRef();
  const mnameRef = useRef();
  const lnameRef = useRef();
  const wingnoRef = useRef();
  const flatnoRef = useRef();
  const numberRef = useRef();
  const passwordRef = useRef();
  const countRef = useRef();
  const [mType, setMType] = useState("Society");

  const submit = async (e) => {
    e.preventDefault();
    let fname = fnameRef.current.value;
    let mname = mnameRef.current.value;
    let lname = lnameRef.current.value;
    let wingno = wingnoRef.current.value;
    let flatno = flatnoRef.current.value;
    let count = countRef.current.value;
    let number = numberRef.current.value;
    let password = passwordRef.current.value;
    let mtype = mType;
    const isValid = passwordValidate(password);
    if (!isValid.valid) {
      alert("Password is not in valid format");
    }
    if (
      fname &&
      mname &&
      lname &&
      wingno &&
      flatno &&
      count &&
      number &&
      password &&
      mtype &&
      isValid.valid
    ) {
      let data = {
        fname: fname,
        mname: mname,
        lname: lname,
        wingno: parseInt(wingno),
        flatno: parseInt(flatno),
        count: parseInt(count),
        number: parseInt(number),
        password: password,
        mtype: mtype,
      };
      const res = await createMember(data);
      if (res.id) {
        alert("Member created succesfully");
        window.location.reload();
      } else {
        alert("Something went wrong");
        window.location.reload();
      }
    }
  };

  if (userType !== "commitie") {
    return <PageNotFound />;
  }

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <br />
      <h2>Register new member</h2>
      <br />
      <Form
        style={{
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
          maxWidth: "500px",
          margin: "auto",
        }}
      >
        <Row>
          <Col>
            <Form.Group className="mb-3" controlId="formBasicFName">
              <Form.Label>Enter First name*</Form.Label>
              <Form.Control
                type="text"
                ref={fnameRef}
                placeholder="Enter First Name"
                required
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group className="mb-3" controlId="formBasicMName">
              <Form.Label>Enter Middle name*</Form.Label>
              <Form.Control
                type="text"
                ref={mnameRef}
                placeholder="Enter Middle Name"
                required
              />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group className="mb-3" controlId="formBasicLName">
              <Form.Label>Enter Last name*</Form.Label>
              <Form.Control
                type="text"
                ref={lnameRef}
                placeholder="Enter Last Name"
                required
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group className="mb-3" controlId="formBasicEName">
              <Form.Label>Family members count*</Form.Label>
              <Form.Control type="number" ref={countRef} required />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group className="mb-3" controlId="formBasicWnumber">
              <Form.Label>Enter Wing number*</Form.Label>
              <Form.Control
                type="number"
                ref={wingnoRef}
                placeholder="Enter Wing Number"
                required
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group className="mb-3" controlId="formBasicFnumber">
              <Form.Label>Enter Flat number*</Form.Label>
              <Form.Control
                type="number"
                ref={flatnoRef}
                placeholder="Enter Flat Number"
                required
              />
            </Form.Group>
          </Col>
        </Row>
        <Form.Group className="mb-3" controlId="formBasicCnumber">
          <Form.Label>Enter Contact number*</Form.Label>
          <Form.Control
            type="number"
            ref={numberRef}
            placeholder="Enter Contact Number"
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicpwd">
          <Form.Label>Enter Password*</Form.Label>
          <Form.Control
            type="text"
            ref={passwordRef}
            placeholder="Create password"
            required
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicEName">
          <Form.Label>Choose member type*</Form.Label>
          <Form.Check
            style={{ maxWidth: "200px", margin: "auto" }}
            type="radio"
            name="type"
            id={"2"}
            onClick={() => setMType("society")}
            label={`Society`}
            checked={mType == "society"}
          />
          <Form.Check
            style={{ maxWidth: "200px", margin: "auto" }}
            type="radio"
            name="type"
            id={"1"}
            onClick={() => setMType("commitie")}
            label={`Commitie`}
            checked={mType == "commitie"}
          />
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
          Submit
        </Button>
      </Form>
    </Container>
  );
}
