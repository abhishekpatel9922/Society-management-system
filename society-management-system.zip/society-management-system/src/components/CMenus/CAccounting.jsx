import React, { useEffect, useRef, useState } from "react";
import { useRecoilState } from "recoil";
import { userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import {
  Button,
  Container,
  Dropdown,
  DropdownButton,
  Form,
} from "react-bootstrap";
import axios from "axios";
import { addBill } from "../../utils/AddBill";

export default function CAccounting() {
  const [userType, setUserType] = useRecoilState(userTypeState);
  const [personName, setPersonName] = useState();
  const [members, setMembers] = useState();

  const monthRef = useRef();
  const monthDueRef = useRef();
  const generalRef = useRef();
  const buildingRef = useRef();
  const commonRef = useRef();
  const chargesRef = useRef();

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await axios("http://localhost:1000/getAllMembers");
      setMembers(res.data);
    };
    getAllMembers();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    let month = monthRef.current.value;
    let monthDue = monthDueRef.current.value;
    let general = generalRef.current.value;
    let building = buildingRef.current.value;
    let common = commonRef.current.value;
    let charges = chargesRef.current.value;

    const data = {
      mdues: monthDue,
      general: general,
      building: building,
      common: common,
      charges: charges,
    };

    const params = {
      params: {
        billmonth: month,
        fname: personName[0],
        lname: personName[1],
      },
    };

    const res = await addBill(data, params);
    if (res.billNo) {
      alert("Bill created successfully");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  if (userType !== "commitie") {
    return <PageNotFound />;
  }
  return (
    <Container
      style={{
        maxWidth: "700px",
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <h2>Create bill</h2>
      <Form
        style={{
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <Form.Group className="mb-3" controlId="formBasicMonth">
          <Form.Label>Choose Bill month and year*</Form.Label>
          <Form.Control type="month" ref={monthRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Person Name*</Form.Label>
          <DropdownButton
            id="dropdown-basic-button"
            title={
              personName ? `${personName[0]} ${personName[1]}` : "Choose Name"
            }
          >
            {members?.map((member) => {
              return (
                <Dropdown.Item
                  onClick={() => setPersonName([member.fname, member.lname])}
                >
                  {`${member.fname} ${member.lname}`}
                </Dropdown.Item>
              );
            })}
          </DropdownButton>
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicMDues">
          <Form.Label>All muncipal Dues</Form.Label>
          <Form.Control
            type="number"
            ref={monthDueRef}
            placeholder="Month Due"
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicGeneral">
          <Form.Label>Administrative and General Expenses</Form.Label>
          <Form.Control type="number" ref={generalRef} placeholder="General" />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicBuildungMaintance">
          <Form.Label>Periodic Building's Maintainance Expenses</Form.Label>
          <Form.Control
            type="number"
            ref={buildingRef}
            placeholder="Building Maintance"
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicCommonBill">
          <Form.Label>Common Area Utilization</Form.Label>
          <Form.Control
            type="number"
            ref={commonRef}
            placeholder="Common Bill"
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicMDues">
          <Form.Label>Non Occupancuy Charges</Form.Label>
          <Form.Control type="number" ref={chargesRef} placeholder="Charges" />
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
          Submit
        </Button>
      </Form>
    </Container>
  );
}
