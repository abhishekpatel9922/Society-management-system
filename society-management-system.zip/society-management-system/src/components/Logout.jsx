import React from "react";
import { Button } from "react-bootstrap";
import { logout } from "../utils/auth";
import { userNameState } from "../atoms";
import { useRecoilState } from "recoil";

export default function Logout() {
  const [userName, setUserName] = useRecoilState(userNameState);

  return (
    <div className="logout">
      <span style={{ fontSize: "20px", color: "white" }}>
        Hi {userName},
        <Button
          variant="danger"
          onClick={() => logout()}
          style={{ marginLeft: "20px" }}
        >
          Logout
        </Button>
      </span>
    </div>
  );
}
